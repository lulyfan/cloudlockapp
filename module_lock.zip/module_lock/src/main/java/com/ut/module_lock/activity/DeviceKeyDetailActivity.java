package com.ut.module_lock.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ut.module_lock.R;

public class DeviceKeyDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_key_detail);
    }
}
