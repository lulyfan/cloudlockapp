package com.ut.module_lock.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;

import com.ut.database.daoImpl.DeviceKeyDaoImpl;
import com.ut.database.entity.DeviceKey;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rx.schedulers.Schedulers;

/**
 * author : zhouyubin
 * time   : 2019/01/08
 * desc   :
 * version: 1.0
 */
public class DeviceKeyVM extends BaseViewModel {
    private ExecutorService mExecutorService = Executors.newSingleThreadExecutor();

    public DeviceKeyVM(@NonNull Application application) {
        super(application);
        //TODO 初始化假数据
        initDeviceKeys();
    }

    public LiveData<List<DeviceKey>> getDeviceKeys(int deviceKeyType) {
        return DeviceKeyDaoImpl.get().findDeviceKeysByType(deviceKeyType);
    }

    public void initDeviceKeys() {
        DeviceKey deviceKey1 = new DeviceKey(0, "", 0, 0, 0);
        DeviceKey deviceKey2 = new DeviceKey(1, "", 0, 1, 1);
        DeviceKey deviceKey3 = new DeviceKey(2, "", 1, 1, 0);
        DeviceKey deviceKey4 = new DeviceKey(3, "", 2, 0, 0);
        DeviceKey deviceKey5 = new DeviceKey(4, "", 2, 1, 1);
        DeviceKey deviceKey6 = new DeviceKey(5, "", 4, 0, 0);
        DeviceKey deviceKey7 = new DeviceKey(6, "", 4, 1, 1);
        List<DeviceKey> deviceKeys = new ArrayList<>();
        deviceKeys.add(deviceKey1);
        deviceKeys.add(deviceKey2);
        deviceKeys.add(deviceKey3);
        deviceKeys.add(deviceKey4);
        deviceKeys.add(deviceKey5);
        deviceKeys.add(deviceKey6);
        deviceKeys.add(deviceKey7);
        mExecutorService.execute(() -> DeviceKeyDaoImpl.get().insertDeviceKeys(deviceKeys));
    }
}
