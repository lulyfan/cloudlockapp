package com.ut.module_lock.adapter;

import android.view.View;

import java.util.List;

/**
 * Created by ZYB on 2017-05-24.
 */

public interface OnRcvItemClickListener {
    void onItemClick(View view, List<?> datas, int position);
}
