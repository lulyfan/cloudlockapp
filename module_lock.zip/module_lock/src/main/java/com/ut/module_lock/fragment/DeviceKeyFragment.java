package com.ut.module_lock.fragment;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.PrimaryKey;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ut.base.common.CommonAdapter;
import com.ut.base.common.CommonViewHolder;
import com.ut.database.entity.DeviceKey;
import com.ut.module_lock.R;
import com.ut.module_lock.databinding.FragmentDeviceKeyBinding;
import com.ut.module_lock.viewmodel.DeviceKeyVM;

import java.util.List;

public class DeviceKeyFragment extends Fragment {
    private static final String EXTRA_KEY_TYPE = "extra_key_type";
    private DeviceKeyVM mDeviceKeyVM;
    private int mDeviceKeyType;
    private CommonAdapter<DeviceKey> mDeviceKeyCommonAdapter;
    private FragmentDeviceKeyBinding mFragmentDeviceKeyBinding = null;


    public DeviceKeyFragment() {
    }

    public static DeviceKeyFragment newInstance(int keyType) {
        DeviceKeyFragment fragment = new DeviceKeyFragment();
        Bundle args = new Bundle();
        args.putInt(EXTRA_KEY_TYPE, keyType);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mFragmentDeviceKeyBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_device_key, container, false);
        View rootView = mFragmentDeviceKeyBinding.getRoot();
        return rootView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        iniData();
        initVM();
    }

    private void iniData() {
        Bundle bundle = getArguments();
        mDeviceKeyType = bundle.getInt(EXTRA_KEY_TYPE);
    }

    private void initVM() {
        mDeviceKeyVM = ViewModelProviders.of(getActivity()).get(DeviceKeyVM.class);
        mDeviceKeyVM.getDeviceKeys(mDeviceKeyType).observe(this, deviceKeys -> {

        });
    }

    private void refreshData(List<DeviceKey> deviceKeys) {
        if (deviceKeys == null) return;
        if (mDeviceKeyCommonAdapter == null) {
            mDeviceKeyCommonAdapter = new CommonAdapter<DeviceKey>(getContext(), deviceKeys, R.layout.item_device_key) {
                @Override
                public void convert(CommonViewHolder commonViewHolder, int position, DeviceKey item) {
                    
                }
            };
            mFragmentDeviceKeyBinding.lvDeviceKey.setAdapter(mDeviceKeyCommonAdapter);
        } else {
            mDeviceKeyCommonAdapter.notifyData(deviceKeys);
        }
    }
}